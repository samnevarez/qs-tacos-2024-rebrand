---
order: 0
---

Use this config directory for all the settings related SCSS;

Example: Sass Variables, Mixins etc. These things on itself dont produce any CSS but they are required by other SCSS files; We use partials for config because we dont want individual CSS for them.